
function confirmEmail() {
    const btn = document.querySelector('.btn');
    btn.textContent = 'VERIFYING...';
    btn.style.background = '#4caf50';

    setTimeout(() => {
        btn.textContent = 'EMAIL CONFIRMED ✓';
        btn.style.cursor = 'default';

        setTimeout(() => {
            alert('Email verification successful! Redirecting to dashboard...');
        }, 1000);
    }, 1500);
}

document.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', (e) => {
        if (link.getAttribute('href') === '#') {
            e.preventDefault();
        }
    });
});
